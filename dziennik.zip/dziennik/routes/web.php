<?php

use App\Http\Controllers\TeacherController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;

// Auth
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::get('/register', [AuthController::class, 'showRegistrationForm'])->name('register');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/register', [AuthController::class, 'register']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Wymagane logowanie
Route::middleware('auth')->group(function ()
{
    // Teacher
    Route::get('/teacher', [TeacherController::class, 'showSubjects'])->name('teacher.subjects');
    Route::get('/teacher/{subjectId}/groups', [TeacherController::class, 'showGroupsForSubject'])->name('teacher.groups');
    Route::get('/teacher/{groupId}/students', [TeacherController::class, 'showStudentsForGroup'])->name('teacher.students');
    // Teacher // Grades
    Route::get('/teacher/{studentId}/grades', [TeacherController::class, 'showGradesForStudent'])->name('teacher.grades');
    Route::get('/teacher/grades/{gradeId}/edit', [TeacherController::class, 'editGrade'])->name('teacher.editGrade');
    Route::post('/teacher/grades/new', [TeacherController::class, 'newGrade'])->name('teacher.newGrade');
    Route::put('/teacher/grades/{gradeId}', [TeacherController::class, 'updateGrade'])->name('teacher.updateGrade');
    Route::post('/teacher/grades', [TeacherController::class, 'storeGrade'])->name('teacher.storeGrade');
});

// Home
Route::get('/', function () {
    return view('home');
})->name('home');