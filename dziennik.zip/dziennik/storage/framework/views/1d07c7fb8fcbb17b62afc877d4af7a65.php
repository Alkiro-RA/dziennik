<h1>classes list</h1>
<button onclick="location.href='<?php echo e(route('home')); ?>'">Powrót</button>

<h1>Lista Nauczanych Klas</h1>
<table border="1" cellspacing="0" cellpadding="5">
    <thead>
        <tr>
            <th>Nazwa Klasy</th>
            <th>Akcje</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($class->name); ?></td>
                <td>
                    <form method="GET" action="<?php echo e(route('teacher.classes', $subject->id)); ?>">
                        <button type="submit">Wybierz</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH E:\Programy\Xampp\htdocs\dziennik\resources\views/teacher/classes.blade.php ENDPATH**/ ?>