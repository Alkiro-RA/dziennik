<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel</title>
    <style>
        header {
            background-color: #f8f9fa;
            padding: 10px;
            position: relative;
        }
        nav {
            display: flex;
            justify-content: flex-end;
        }
        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }
        nav ul li {
            display: inline-block;
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <ul>
                <?php if(auth()->guard()->guest()): ?>
                    <!-- Jeśli użytkownik nie jest zalogowany -->
                    <li><a href="<?php echo e(route('login')); ?>">Zaloguj</a></li>
                    <li><a href="<?php echo e(route('register')); ?>">Zarejestruj</a></li>
                <?php else: ?>
                    <!-- Jeśli użytkownik jest zalogowany -->
                    <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Wyloguj</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Formularz wylogowania -->
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>
</body>
</html>
<?php /**PATH E:\Programy\Xampp\htdocs\dziennik\resources\views/layouts/app.blade.php ENDPATH**/ ?>