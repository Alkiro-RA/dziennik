

<?php $__env->startSection('content'); ?>
    <?php if(Auth::check()): ?>
    
        <h1>Witaj, <?php echo e(Auth::user()->name); ?>!</h1>

        <?php if(Auth::user()->role == 'uczen'): ?>
        
            <h2>Panel ucznia</h2>
        
        <?php elseif(Auth::user()->role == 'nauczyciel'): ?>
        
            <h2>Panel nauczyciela</h2>
            <button onclick="location.href='<?php echo e(route('teacher.subjects')); ?>'">Przejdź do listy przedmiotów</button>
        
        <?php elseif(Auth::user()->role == 'admin'): ?>
        
            <h2>Panel administratora</h2>
        
        <?php endif; ?>
    
    <?php else: ?>
        <h1>Witaj w dzienniku. Zaloguj się lub załóż konto</h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Programy\Xampp\htdocs\dziennik\resources\views/home.blade.php ENDPATH**/ ?>