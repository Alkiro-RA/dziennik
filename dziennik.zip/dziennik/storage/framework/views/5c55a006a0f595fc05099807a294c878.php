<h1>Edytuj ocenę</h1>
<form method="POST" action="<?php echo e(route('teacher.updateGrade', $grade->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <label for="grade">Ocena:</label>
    <input type="text" name="grade" id="grade" value="<?php echo e($grade->grade); ?>" required>
    <label for="comment">Komentarz:</label>
    <textarea name="comment" id="comment"><?php echo e($grade->comment); ?></textarea>
    <button type="submit">Zapisz zmiany</button>
</form><?php /**PATH E:\Programy\Xampp\htdocs\dziennik\resources\views/teacher/editGrade.blade.php ENDPATH**/ ?>