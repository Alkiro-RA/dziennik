<h1>Uczniowie przypisani do grupy: <?php echo e($group->name); ?></h1>
<button onclick="location.href='<?php echo e(route('teacher.subjects')); ?>'">Powrót</button>


<h1>Lista Uczniów</h1>
<table border="1" cellspacing="0" cellpadding="5">
    <thead>
        <tr>
            <th>Imię ucznia</th>
            <th>Akcje</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($student->name); ?>

                </td>
                <td>
                    <form method="GET" action="<?php echo e(route('teacher.grades', $student->id)); ?>">
                        <input type="hidden" name="subjectId" value="<?php echo e($subjectId); ?>">
                        <button type="submit">Wybierz</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH E:\Programy\Xampp\htdocs\dziennik\resources\views/teacher/students.blade.php ENDPATH**/ ?>