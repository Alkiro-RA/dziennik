<h1>Dodaj nową ocenę dla ucznia</h1>

<form method="POST" action="<?php echo e(route('teacher.storeGrade')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="user_id" value="<?php echo e($studentId); ?>">
    <input type="hidden" name="subject_id" value="<?php echo e($subjectId); ?>">

    <label for="grade">Ocena:</label>
    <input type="text" id="grade" name="grade" required>

    <label for="comment">Komentarz:</label>
    <textarea id="comment" name="comment" rows="4"></textarea>

    <button type="submit">Zapisz ocenę</button>
</form>
<?php /**PATH E:\Programy\Xampp\htdocs\dziennik\resources\views/teacher/newGrade.blade.php ENDPATH**/ ?>