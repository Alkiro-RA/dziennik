<h1>Oceny ucznia <?php echo e($student->name); ?> </h1>
<h2>Przedmiot <?php echo e($subject->name); ?></h2>
<button onclick="location.href='<?php echo e(route('teacher.subjects')); ?>'">Powrót</button>
<!-- dodaj parametr groupId i zrób wracanie do grupy -->

<h1>Lista Ocen</h1>
<table border="1" cellspacing="0" cellpadding="5">
    <thead>
        <tr>
            <th>Ocena</th>
            <th>Komentarz</th>
            <th>Akcje</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($grade->grade); ?>

                </td>
                <td>
                    <?php echo e($grade->comment); ?>

                </td>
                <td>
                <form method="GET" action="<?php echo e(route('teacher.editGrade', $grade->id)); ?>">
                        <button type="submit">Edytuj ocenę</button>
                    </form>
                    <!-- tu odpalanie mini formularza do edycji oceny? -->
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<br>
<form method="POST" action="<?php echo e(route('teacher.newGrade')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="studentId" value="<?php echo e($student->id); ?>">
    <input type="hidden" name="subjectId" value="<?php echo e($subject->id); ?>">
    <button type="submit">Nowa ocena</button>
</form><?php /**PATH E:\Programy\Xampp\htdocs\dziennik\resources\views/teacher/grades.blade.php ENDPATH**/ ?>