

<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <label for="email">E-mail:</label>
        <input type="email" name="email" id="email" required><br>

        <label for="password">Hasło:</label>
        <input type="password" name="password" id="password" required><br>

        <button type="submit">Zaloguj</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Programy\Xampp\htdocs\dziennik\resources\views/auth/login.blade.php ENDPATH**/ ?>